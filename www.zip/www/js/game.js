var bounds = 3000;
var text, star, stars;
var left = false;
var right = false;
var x,y;
var player2;
var score = 0;
var scoreText;
var demonyos;
var bestScoreText;
var bituins;
var Game = {
 preload: function() {
 
            game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
            game.scale.pageAlignHorizontally = true;
            game.scale.pageAlignVertically = true;
            game.stage.backgroundColor = 'blue';    
            game.load.image("sky", 'assets/bg.png');
            game.load.image("star", 'assets/tao.png');
            game.load.spritesheet("tao", 'assets/chichay.png',60, 60);
                game.load.spritesheet("enemy", 'assets/enemy.png',30, 48);
            game.load.image("cloud1", 'assets/cloud1.png');
            game.load.image("btnRight","assets/btnright.png");
            game.load.image("left","assets/left.png");
            game.load.image("btnUp","assets/up.png");
            game.load.image("btnDown","assets/down.png");
             game.load.image("star2","assets/star.png");
            game.load.audio("bgMusic","music/Automation.mp3");
            game.load.audio("soundeffects","music/soundeffects.wav");

},
 create: function() {

            game.physics.startSystem(Phaser.Physics.ARCADE);
            game.world.setBounds(0,0,bounds,0);
            game.add.sprite(0, 0, 'sky');
            game.add.sprite(890, 0, 'sky');
            game.add.sprite(1400, 0, 'sky');

            platforms = game.add.group();
            platforms.enableBody = true;

             process.createBituins(2000);   
            bituin = game.add.group();
            bituin.enableBody=true;
            process.createStars(3000);
            star = game.add.group();
            star.enableBody = true;

            bgAudio = game.add.audio("bgMusic");
            bgAudio.play();
            process.audio(39000);

            soundeffects = game.add.audio("soundeffects");
            

            player = game.add.sprite(200, game.world.height - 400, 'tao');
            game.physics.arcade.enable(player);
            player.body.bounce.y = 0.2;
            player.body.gravity.y = 300;
            player.body.collideWorldBounds = true;

           buttonleft = game.add.button(96, 500, 'left',process.left);
                buttonleft.anchor.setTo(0.5, 0.5);
                buttonleft.fixedToCamera = true;
                buttonleft.events.onInputOver.add(function(){left=true;});
                buttonleft.events.onInputOut.add(function(){left=false;});
                buttonleft.events.onInputDown.add(function(){left=true;});
                buttonleft.events.onInputUp.add(function(){left=false;});
              
             buttonright = game.add.button(300, 500, 'btnRight',process.right);
                buttonright.anchor.setTo(0.5, 0.5);
                buttonright.fixedToCamera = true;
                buttonright.events.onInputOver.add(function(){right=true;});
                buttonright.events.onInputOut.add(function(){right=false;});
                buttonright.events.onInputDown.add(function(){right=true;});
                buttonright.events.onInputUp.add(function(){right=false;});
                btn = game.add.button(600,450,"btnUp",process.jump);
                btn.fixedToCamera=true;

            

            player.animations.add('left', [0,1,2,3],7, true); 
            player.animations.add('right', [8,9,10,11],7, true); 

             bestScoreText = game.add.text(16,45, 'BestScore: '+process.getScore(),{fill:'pink'});
   bestScoreText.fixedToCamera = true;

            scoreText = game.add.text(16, 16, 'Score: 0', { fontSize: '32px', fill: 'pink' });
            scoreText.fixedToCamera = true;    
            messageText = game.add.text(180, 180, '', { fontSize: '120px', fill: 'red' });
            messageText.fixedToCamera = true;

            game.camera.follow(player, Phaser.Camera.FOLLOW_TOPDOWN);
            game.camera.follow(player, Phaser.Camera.FOLLOW_LOCKON);

            cursors = game.input.keyboard.createCursorKeys();          
            
 },

update: function() {

    game.physics.arcade.collide(player);
     game.physics.arcade.overlap(player, bituin, process.collectBituin, null, this);
    game.physics.arcade.overlap(player, star, process.collectStar, null, this);

     if (left) {
               
                player.body.velocity.x=-320;
                player.animations.play('left');
                  
                 
    }

            
            else if (right) {
          
                player.body.velocity.x=320;
                player.animations.play('right');
                 
       
    }

            
            else {
                   player.body.velocity.x=0;

              player.frame = 1;
            }

            if (game.input.currentPointers == 0 && !game.input.activePointer.isMouse){ fire=false; right=false; left=false; duck=false; jump=false;} //this 
        }

}

game.state.add("Game" ,Game, false);