bootGame = 
{
	create: function()
	{  
		game.physics.startSystem(Phaser.Pysics.ARCADE);
		keyboard = game.input.keyboard.createCursorKeys();
		game.state.start("preloadGame");
	},
}
