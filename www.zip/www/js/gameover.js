var Gameover = {
	   preload : function() {
      game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
            game.scale.pageAlignHorizontally = true;
            game.scale.pageAlignVertically = true;
            game.stage.backgroundColor = 'blue';   
        game.load.image('menu', 'assets/images.png');
         
    },

    create: function () {
        // Add a sprite to your game, here the sprite will be the game's logo
        // Parameters are : X , Y , image name (see above) 
        this.add.sprite(0, 0, 'menu');
             this.add.button(0, 0, 'menu', this.startGame, this);
    },

    startGame: function () {

        // Change the state to the actual game.
        this.state.start('Game');

    }


};
game.state.add("Gameover",Gameover,false);