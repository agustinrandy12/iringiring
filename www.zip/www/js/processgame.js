var process = function() {
	   "use strict";
        return {


 createStars : function(time) {
    setInterval(function() {
        stars= star.create(Math.random()*3000, -100, "star");
        stars.body.gravity.y = 30;

          stars= star.create(Math.random()*3000, -100, "star");
        stars.body.gravity.x = 30;
             
             stars= star.create(Math.random()*3000, 300, "star");
         stars.body.gravity.x = -30;

            stars= star.create(Math.random()*3000, 550, "star");
         stars.body.gravity.x = -30;
 
 

        stars.body.collideWorldBounds = false;
    },time);
}, 

 createBituins : function(time) {
    setInterval(function() {
        bituins= bituin.create(Math.random()*3000, -100, "star2");
        bituins.body.gravity.y = 60;
      
         bituins= bituin.create(Math.random()*3000, -100, "star2");
        bituins.body.gravity.y = 60;
      
        bituins= bituin.create(Math.random()*3000, -100, "star2");
        bituins.body.gravity.y = 60;

        bituins.body.collideWorldBounds = false;
    },time);
}, 


 collectStar: function (player, star) {
        player.kill();
    score += 10;
  /*     if(getScore()<=score){
        saveScore(score);
        bestScoreText.text= "BestScore:  "+score;
    }*/
    game.state.start("Gameover");
},


 collectBituin: function (player, bituin) {
        bituin.kill();
    score += 10;
    if(process.getScore()<=score){
        process.saveScore(score);
        bestScoreText.text= "BestScore:  "+score;
    }

    scoreText.text = 'Score: ' + score;
   
},
audio : function(time){
    setInterval(function(){
        bgAudio.play();
        },time)
 

},

jump : function(){
    player.body.velocity.y = -350;

},
 saveScore : function(score){
    localStorage.setItem("gameScore",score);
},

 getScore : function(){
    return (localStorage.getItem("gameScore") == null || localStorage.getItem("gameScore") == "")?0:localStorage.getItem("gameScore");
   /* var data = localStorage.getItem("gameData");
    if(data == null || data == "") {
        data = 0;
    }*/
},

left : function(){
   
      score += 10;
       if(process.getScore()<=score){
        process.saveScore(score);
        bestScoreText.text= "BestScore:  "+score;
    }

  
},

right : function(){
     
     score += 10;
       if(process.getScore()<=score){
        process.saveScore(score);
        bestScoreText.text= "BestScore:  "+score;
    }


        
},
}
}();